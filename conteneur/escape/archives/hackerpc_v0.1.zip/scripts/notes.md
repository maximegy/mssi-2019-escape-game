# NOTES 

## Description des scripts 
[launcher] - lance les autres scripts
[escape\_f\_util] - contient les fonctions commune et utilitaire
[settings.ini] - Options et parametres pour l'escape game
[m\_\*] - script qui gére les différents menu
[boot] - script qui simule un lancement du poste de la hackeuse

## Déroulé des scripts 
launch -> start\_poste -> m\_principal

## A FAIRE
### PRIORITAIRE
- [ ] Rajouter le sous menu maltego
- [x] Rajouter le sous menu connexion a distance
- [x] Rajouter le sous menu boite mail
- [x] Rajouter le sous menu journal
- [x] Rajouter des instructions en gras pour plus de lisabilité
- [x] Séparer le tout en plusieurs scripts
- [ ] Faire un cron avec un script type 'keep alive' qui relance le script de la hackeuse en cas de fermeture de la fenetre avec la croix
- [ ] Mettre en place un systeme de message pour recevoir des messages des MJ
- [ ] Mettre en place une interface avec un timer

### SECONDAIRE
- [x] Syncroniser tout les sleeps avec les valeurs en settings
- [x] Ameliorer le demarage du poste
- [x] Embellir le menu
- [x] Rajouter un fichier de settings avec par exemples les differents modes d'utiliation ou les temps de sleep
- [x] Faire un script qui export les commentaires en debuts de script pour les décrires
- [ ] Mettre le code en anglais et les commentaires en FR
- [ ] Dans la validation des donnees afficher les retour alignées avec column
- [x] Rajouter tout les fichiers et constantes utilisés dans la validation des données
- [ ] Finir la partie DEBUG qui desactive les touches ctrl


